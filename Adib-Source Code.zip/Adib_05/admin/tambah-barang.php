<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" >

    <title>APP KASIR | ADMIN</title>
  </head>
  <body>
    
    <nav class="navbar navbar-expand-lg navbar-light bg-info">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">App Kasir</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        </li>
           <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Barang
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="tambah-barang.php">Tambah Barang</a></li>
            <li><a class="dropdown-item" href="tampil-barang.php">Tampil Barang</a></li>
            <li><a class="dropdown-item" href="Cetak-barang.php" target="_blank">Cetak Barang</a></li>
          </ul>
        </li>
         <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Pelanggan
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="tambah-Pelanggan.php">Tambah Pelanggan</a></li>
            <li><a class="dropdown-item" href="tampil_pelanggan.php">Tampil Pelanggan</a></li>
            <li><a class="dropdown-item" href="cetak-pelanggan.php"target="_blank">Cetak Pelanggan</a></li>
          </ul>
        </li>
         <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            User
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="tambah-user.php">Tambah User</a></li>
            <li><a class="dropdown-item" href="tampil-user.php">Tampil User</a></li>
            <li><a class="dropdown-item" href="cetak-user.php"target="_blank">Cetak User</a></li>
          </ul>
        </li>
         <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="../config/logout.php" onclick="return confirm('Apakah Anda Yakin Ingin Logout ???')">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

    <div class="container-fluid">
      <h3>Tambah Barang</h3>
    </div>

    <div class="row">
      <form class="row g-3" action="simpan-barang.php" method="post">
        <div class="col-12">
          <label for="id_barang" class="form-label">ID Barang</label>
          <input type="number" class="form-control" name="id_barang" id="id_barang" 
                 placeholder="ID Barang" required onblur="checkIdBarang()">
        </div>
        <div class="col-12">
          <label for="nama_barang" class="form-label">Nama Barang</label>
          <input type="text" class="form-control" name="nama_barang" 
                 id="nama_barang" placeholder="Nama Barang" required>
        </div>
        <div class="col-12">
          <label for="harga" class="form-label">Harga Barang</label>
          <input type="text" class="form-control" name="harga" 
                 id="harga" placeholder="Harga Barang" required>
        </div>
        <div class="col-12">
          <label for="stok" class="form-label">Stok Barang</label>
          <input type="text" class="form-control" name="stok" 
                 id="stok" placeholder="Stok Barang" required>
        </div>
        <div class="col-12">
          <!-- Tombol Simpan akan dinonaktifkan jika ID Barang sudah ada -->
          <button type="submit" class="btn btn-primary" id="btnSimpan">Simpan</button>
        </div>
      </form>
    </div>

    <!-- Bootstrap Bundle JS -->
    <script src="../assets/js/bootstrap.bundle.min.js"></script>

    <script>
      // Fungsi untuk mengecek apakah ID Barang sudah ada di DB
      function checkIdBarang() {
        let id_barang = document.getElementById('id_barang').value;
        
        // Jika user belum mengetik apa-apa, tidak perlu cek
        if (id_barang === '') {
          return;
        }

        // Membuat request AJAX
        let xhr = new XMLHttpRequest();
        xhr.open('POST', 'check_id_barang.php', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

        xhr.onload = function() {
          if (this.status === 200) {
            // Respons 'exists' atau 'not_exists'
            if (this.responseText.trim() === 'exists') {
              alert('ID Barang sudah ada. Gunakan ID lain!');
              // Nonaktifkan tombol Simpan
              document.getElementById('btnSimpan').disabled = true;
            } else {
              // Aktifkan tombol Simpan jika ID belum ada
              document.getElementById('btnSimpan').disabled = false;
            }
          }
        };
        
        xhr.send('id_barang=' + encodeURIComponent(id_barang));
      }
    </script>
  </body>
</html>
