<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" >
    <title>Aplikasi Kasir</title>
  <script language="javascript1.2">
  function printpage() {
  	window.print();
  }
  </script>
  </head>
  <body onload="printpage()">
  <h2>
  	<center>Data Pelanggan</center>
  </h2>
  <table border="1" align="center">
  	<tr>
  		<th>NO</th>
  		<th>ID Pelanggan</th>
  		<th>Nama Pelanggan</th>
  		<th>Alamat</th>
  		<th>Nomor Telepon</th>
  	</tr>
  	<?php
  include("../config/koneksi.php");
  $i = 1;
  $query = mysqli_query($config, "select * from pelanggan");
  while ($data = mysqli_fetch_array($query)) {
  echo "<tr>
  <td>$i</td>
  <td>$data[id_pelanggan]</td>
  <td>$data[nama]</td>
  <td>$data[alamat]</td>
  <td>$data[nomor_hp]</td>
  	</tr>";

  	$i = $i + 1;
  	}
  	?>
  </body>
  </html>

  