<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" >
    <title>Aplikasi Kasir</title>
  <script language="javascript1.2">
  function printpage() {
    window.print();
  }
  </script>
  </head>
  <body onload="printpage()">
  <h2>
    <center>Data User</center>
  </h2>
  <table border="1" align="center">
    <tr>
      <th>NO</th>
      <th>ID User</th>
      <th>Nama</th>
      <th>Username</th>
      <th>Password</th>
    </tr>
    <?php
  include("../config/koneksi.php");
  $i = 1;
  $query = mysqli_query($config, "select * from user");
  while ($data = mysqli_fetch_array($query)) {
  echo "<tr>
  <td>$i</td>
  <td>$data[id_user]</td>
  <td>$data[nama]</td>
  <td>$data[username]</td>
  <td>$data[password]</td>
    </tr>";

    $i = $i + 1;
    }
    ?>
  </body>
  </html>

  