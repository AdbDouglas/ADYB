<?php
// check_id_barang.php
include("../config/koneksi.php");

if (isset($_POST['id_barang'])) {
    $id_barang = $_POST['id_barang'];

    // Query untuk cek apakah ID Barang sudah ada
    $check = mysqli_query($config, "SELECT * FROM barang WHERE id_barang = '$id_barang'");
    
    // Jika ditemukan data dengan ID yang sama, kembalikan respons 'exists'
    if (mysqli_num_rows($check) > 0) {
        echo 'exists';
    } else {
        echo 'not_exists';
    }
}
?>
