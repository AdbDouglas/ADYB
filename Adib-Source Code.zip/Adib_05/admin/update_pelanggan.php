<?php
include("../config/koneksi.php");
$id_pelanggan = $_POST['id_pelanggan'];
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$nomor_hp= $_POST['nomor_hp'];

$query = mysqli_query($config, "update pelanggan set id_pelanggan='$id_pelanggan', nama ='$nama', alamat ='$alamat', nomor_hp='$nomor_hp' where id_pelanggan='$id_pelanggan'");

if ($query) {
	echo "<script>alert('Data Pelanggan Di Update !!!');location.href=('tampil_pelanggan.php');</script>";
} else {
	echo "<script type='text/javascript'>alert('Data Pelanggan Gagal Di Update !!!'); history.back(self);</script>'";
}
?>