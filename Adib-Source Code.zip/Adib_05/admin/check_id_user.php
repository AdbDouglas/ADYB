<?php
// check_id_user.php
include("../config/koneksi.php");

if (isset($_POST['id_user'])) {
    $id_user = $_POST['id_user'];

    // Query untuk cek apakah ID User sudah ada
    $check = mysqli_query($config, "SELECT * FROM user WHERE id_user = '$id_user'");
    
    // Jika ditemukan data dengan ID yang sama, kembalikan respons 'exists'
    if (mysqli_num_rows($check) > 0) {
        echo 'exists';
    } else {
        echo 'not_exists';
    }
}
?>
