<?php include "Tampil-Barang.php" ?>
include("../config/koneksi.php");
<?php
$hasil = $_REQUEST['id_barang'];
$perintah = mysqli_query($config, "delete from barang where id_barang='$hasil'");
if ($perintah) {
	echo "<script>alert('Data Barang Berhasil Di Hapus!');
	location.href=('Tampil-Barang.php');
	</script>;
	";
} else {
	echo mysqli_error($config);
	//echo "<script>alert('Data Barang Gagal Di Hapus!'); history.back(self)</script>;";
}
?>