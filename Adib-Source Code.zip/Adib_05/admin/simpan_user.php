<?php
include("../config/koneksi.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Menghindari SQL Injection
    $id_user   = mysqli_real_escape_string($config, $_POST['id_user']);
    $nama      = mysqli_real_escape_string($config, $_POST['nama']);
    $username  = mysqli_real_escape_string($config, $_POST['username']);
    $password  = mysqli_real_escape_string($config, $_POST['password']);
    $role      = mysqli_real_escape_string($config, $_POST['role']);

    // Enkripsi password dengan MD5
    $password_md5 = md5($password);

    // Query INSERT ke database
    $query = mysqli_query($config, 
        "INSERT INTO user (id_user, nama, username, password, role) 
         VALUES ('$id_user', '$nama', '$username', '$password_md5', '$role')"
    );

    if ($query) {
        echo "<script>alert('Data User Tersimpan!'); window.location.href='tampil-user.php';</script>";
    } else {
        echo "<script>alert('Data User Gagal Tersimpan!'); window.history.back();</script>";
    }
}
?>
