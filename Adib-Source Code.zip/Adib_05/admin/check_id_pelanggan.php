<?php
// check_id_pelanggan.php
include("../config/koneksi.php");

// Pastikan data dikirim via POST
if (isset($_POST['id_pelanggan'])) {
    $id = $_POST['id_pelanggan'];

    // Query cek apakah ID sudah ada
    $check = mysqli_query($config, "SELECT * FROM pelanggan WHERE id_pelanggan = '$id'");
    
    // Jika ditemukan data dengan ID yang sama, kembalikan respons 'exists'
    if (mysqli_num_rows($check) > 0) {
        echo 'exists';
    } else {
        echo 'not_exists';
    }
}
