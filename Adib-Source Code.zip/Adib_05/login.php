<?php
session_start();
include("config/koneksi.php");

// Pastikan form disubmit via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $username = mysqli_real_escape_string($config, $_POST['username']);
    $password = $_POST['password']; // password asli (plain text)

    // Cari user berdasarkan username
    $query = "SELECT * FROM user WHERE username = '$username'";
    $result = mysqli_query($config, $query);
    $data   = mysqli_fetch_assoc($result);

    if ($data) {
        // Cek password dengan password_verify
        if (password_verify($password, $data['password'])) {
            // Password cocok
            $_SESSION['username'] = $data['username'];
            $_SESSION['role']     = $data['role'];

            // Arahkan sesuai role
            if ($data['role'] == "Admin") {
                header("Location: admin/index.php");
            } elseif ($data['role'] == "Petugas") {
                header("Location: petugas/index.php");
            } else {
                echo "<script>alert('Role tidak dikenali!'); window.location='index.php';</script>";
            }
            exit();
        } else {
            // Password salah
            echo "<script>alert('Password salah!'); window.location='index.php';</script>";
            exit();
        }
    } else {
        // Username tidak ditemukan
        echo "<script>alert('Username tidak ditemukan!'); window.location='index.php';</script>";
        exit();
    }
} else {
    // Jika file ini diakses tanpa submit form, arahkan ke login
    header("Location: index.php");
    exit();
}
?>
