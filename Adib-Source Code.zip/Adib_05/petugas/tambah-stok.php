<?php
session_start();
if (!isset ($_SESSION['username'])){
  header(header:"location:../index.php");
  exit();
}
?><?php
// Koneksi ke database
include("../config/koneksi.php");

// Ambil ID barang dari parameter
$id_barang = $_GET['id_barang'] ?? null;

// Proses form jika ada data yang dikirim
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$stok_tambah = (int)$_POST['stok_tambah'];

	if ($stok_tambah > 0) {
		// Update stok barang
		$query = " UPDATE barang SET stok = stok + $stok_tambah WHERE id_barang = '$id_barang'";
		if (mysqli_query($config, $query)) {
			echo "<script>alert('Data Stok Barang Berhasil ditambahkan !!!');location.href=('Tampil-Barang.php');</script>";
		} else {
			echo "Gagal menambahkan stok: " . mysql_error($config);
		}
	} else {
		echo "<script type='text/javascript'>alert(Jumlah stok harus lebih dari 0 !!!'); history.back(self);</script>'";
	}
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" >

    <title>APP KASIR | HOME</title>
  </head>
  <body>
    
    <nav class="navbar navbar-expand-lg navbar-light bg-success">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">App Kasir</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        </li>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Penjualan
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="tambah-penjualan.php">Tambah Data</a></li>
            <li><a class="dropdown-item" href="tampil-penjualan.php">Tampil Data</a></li>
            <li><a class="dropdown-item" href="cetak-penjualan.php" target="_blank">Cetak Data</a></li>
          </ul>
        </li>
           <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Barang
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="tambah-barang.php">Tambah Barang</a></li>
            <li><a class="dropdown-item" href="Tampil-Barang.php">Tampil Barang</a></li>
            <li><a class="dropdown-item" href="cetak_barang.php" target="_blank">Cetak Barang</a></li>
          </ul>
        </li>
         <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Pelanggan
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="tambah-Pelanggan.php">Tambah Pelanggan</a></li>
            <li><a class="dropdown-item" href="tampil_pelanggan.php">Tampil Pelanggan</a></li>
            <li><a class="dropdown-item" href="cetak_pelanggan.php" target="_blank">Cetak Pelanggan</a></li>
          </ul>
        </li>
         
         <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="../config/logout.php" onclick="return confirm('Apakah Anda Yakin Ingin Logout ???')">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>


<div class="container-fluid">
	<h3>Tambah Stok Barang</h3>
	<div class="row">
		
		<form action="" method="POST">
			<label for="stok_tambah" class="form-label">Jumlah Tambah Stok:</label>
			<input type="number" id="stok_tambah" class="form-control" name="stok_tambah" required placeholder="Jumlah Stok Barang">
			<br>
			<button type="submit" class="btn btn-primary">Tambah Stok</button>
		</form>
	</div>
</div>