<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk Penjualan</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid black; padding: 8px; text-align: left; }
        .product-row { margin-bottom: 10px; }
        .btn { padding: 8px; cursor: pointer; }
    </style>
</head>
<body>
    <h2>Penjualan Produk</h2>
    <label for="ID_Pelanggan">Pilih Pelanggan:</label>
    <select id="ID_Pelanggan">
        <option value="1">John Doe</option>
        <option value="2">Jane Smith</option>
    </select>
    <label for="tgl_penjualan">Tanggal:</label>
    <input type="date" id="tgl_penjualan">
    
    <div id="product-container">
        <div class="product-row">
            <select onchange="updateSubtotal(this)">
                <option data-harga="10000">Produk A - Rp 10.000</option>
                <option data-harga="20000">Produk B - Rp 20.000</option>
            </select>
            <input type="number" name="jumlah[]" placeholder="Jumlah" oninput="updateSubtotal(this)">
            <input type="text" name="subtotal[]" placeholder="Subtotal" readonly>
            <button class="btn" onclick="removeRow(this)">Hapus</button>
        </div>
    </div>
    <button class="btn" onclick="addRow()">Tambah Produk</button>
    <button class="btn" onclick="generateStruk()">Buat Struk</button>
    <button class="btn" onclick="cetakStruk()">Cetak Struk</button>
    
    <div id="strukContent"></div>
    
    <script>
        function addRow() {
            const productContainer = document.getElementById("product-container");
            const newRow = document.querySelector(".product-row").cloneNode(true);
            productContainer.appendChild(newRow);
        }

        function removeRow(button) {
            button.closest('.product-row').remove();
        }

        function updateSubtotal(input) {
            const row = input.closest('.product-row');
            const select = row.querySelector('select');
            const quantity = row.querySelector('input[name="jumlah[]"]').value;
            const price = select.options[select.selectedIndex].getAttribute('data-harga');
            const subtotalInput = row.querySelector('input[name="subtotal[]"]');
            
            if (quantity && price) {
                const subtotal = quantity * price;
                subtotalInput.value = subtotal;
            }
        }

        function generateStruk() {
            const pelangganSelect = document.getElementById("ID_Pelanggan");
            const pelangganText = pelangganSelect.options[pelangganSelect.selectedIndex].text;
            const tanggal = document.getElementById("tgl_penjualan").value;
            
            let strukHTML = `
              <h4 class='text-center'>Struk Penjualan</h4>
              <p><strong>ID Pelanggan: </strong> ${pelangganText}</p>
              <p><strong>Tanggal:</strong> ${tanggal}</p>
              <table>
                <tr>
                  <th>Barang</th>
                  <th>Jumlah</th>
                  <th>Sub Total</th>
                </tr>`;

            const rows = document.querySelectorAll('.product-row');
            rows.forEach(row => {
                const productName = row.querySelector('select option:checked').textContent;
                const quantity = row.querySelector('input[name="jumlah[]"]').value;
                const subtotal = row.querySelector('input[name="subtotal[]"]').value;

                strukHTML += `
                <tr>
                  <td>${productName}</td>
                  <td>${quantity}</td>
                  <td>Rp ${subtotal}</td>
                </tr>`;
            });
            
            strukHTML += `</table>`;
            document.getElementById("strukContent").innerHTML = strukHTML;
        }

        function cetakStruk() {
            let newTab = window.open('', '_blank');
            let content = `
                <html>
                <head>
                    <title>Struk Penjualan</title>
                    <style>
                        body { font-family: Arial, sans-serif; padding: 20px; }
                        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                        th, td { border: 1px solid black; padding: 8px; text-align: left; }
                    </style>
                </head>
                <body>
                    ${document.getElementById("strukContent").innerHTML}
                    <script>
                        window.onload = function() {
                            setTimeout(() => { window.print(); window.close(); }, 500);
                        };
                    <\/script>
                </body>
                </html>`;
            newTab.document.write(content);
            newTab.document.close();
        }
    </script>
</body>
</html>