<?php include "tampil-penjualan.php" ?>
include("../config/koneksi.php");
<?php
$hasil = $_REQUEST['id_penjualan'];
$perintah = mysqli_query($config, "delete from penjualan where id_penjualan='$hasil'");
if ($perintah) {
	echo "<script>alert('Data Penjualan Berhasil Di Hapus!');
	location.href=('tampil-penjualan.php');
	</script>;
	";
} else {
	echo mysqli_error($config);
	//echo "<script>alert('Data Penjualan Gagal Di Hapus!'); history.back(self)</script>;";
}
?>