<?php
include("../config/koneksi.php");
$ID_User = $_POST['ID_User'];
$Nama = $_POST['Nama'];
$Username = $_POST['Username'];
$Password = $_POST['Password'];
$Role = $_POST['Role'];

$query = mysqli_query($config, "update user set ID_User='$ID_User', Nama='$Nama', Username='$Username', Password='$Password', Role='$Role' where ID_User='$ID_User'");
	
if ($query) {
	echo "<script>alert('Data User Berhasil Di Update !!!');location.href=('tampil-user.php');</script>";
}else {
	echo "<script type='text/javascript'>alert('Data User Gagal Di Update !!!'); history.back(self);</script>'";
}
?>