<?php
include("../config/koneksi.php");
$ID_User = $_POST['ID_User'];
$Nama = $_POST['Nama'];
$Username = $_POST['Username'];
$Password = $_POST['Password'];
$Role = $_POST['Role'];

$query = mysqli_query ($config, "insert into user (ID_User, Nama, Username, Password, Role) values ('$ID_User','$Nama','$Username','$Password','$Role')");
if ($query) {
  echo "<script>alert('Data User Tersimpan !!!');location.href=('tampil-user.php');</script>";
}else{
     echo mysqli_error($config);
  //echo "<script type='text/javascript'>alert('Data User Gagal Tersimpan !!!'); history.back(self);</script>'";
}
?>