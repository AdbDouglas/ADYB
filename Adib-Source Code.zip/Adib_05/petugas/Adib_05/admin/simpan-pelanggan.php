<?php
include("../config/koneksi.php");
$ID_Pelanggan = $_POST['ID_Pelanggan'];
$Nama_Pelanggan = $_POST['Nama_Pelanggan'];
$Alamat = $_POST['Alamat'];
$Nomer_Telepon = $_POST['Nomer_Telepon'];

$query = mysqli_query($config, "insert into pelanggan (ID_Pelanggan, Nama_Pelanggan, Alamat, Nomer_Telepon) values ('$ID_Pelanggan','$Nama_Pelanggan','$Alamat','$Nomer_Telepon')");
if ($query) {
	echo "<script>alert('Data Pelanggan Tersimpan !!!');location.href=('tampil-pelanggan.php');</script>";
}else{
     
	//echo "<script type='text/javascript'>alert('Data Produk Gagal Tersimpan !!!'); history.back(self);</script>'";
}
?>