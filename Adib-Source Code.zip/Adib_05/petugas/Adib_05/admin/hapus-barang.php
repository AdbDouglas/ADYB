
<?php
include("../config/koneksi.php");
$hasil = $_REQUEST['ID_Barang'];
$perintah = mysqli_query($config, "delete from barang where ID_Barang='$hasil'");
if ($perintah) {
	echo "<script>alert('Data Barang Berhasil Di Hapus!');
	location.href=('tampil-barang.php');
	</script>;
";
} else{
	echo mysqli_error($config);
	//echo "<script>alert('Data Barang Gagal Di Hapus!'); history.back(self)</script>;";
}
?>