<?php
include("../config/koneksi.php");
$ID_Barang = $_POST['ID_Barang'];
$Nama_Barang = $_POST['Nama_Barang'];
$Harga_Barang = $_POST['Harga_Barang'];
$Stok_Barang = $_POST['Stok_Barang'];

$query = mysqli_query ($config, "insert into barang (ID_Barang, Nama_Barang, Harga_Barang, Stok_Barang) values ('$ID_Barang','$Nama_Barang','$Harga_Barang','$Stok_Barang')");
if ($query) {
	echo "<script>alert('Data Barang Tersimpan !!!');location.href=('tampil-barang.php');</script>";
}else{
     echo mysqli_error($config);
	//echo "<script type='text/javascript'>alert('Data Produk Gagal Tersimpan !!!'); history.back(self);</script>'";
}
?>