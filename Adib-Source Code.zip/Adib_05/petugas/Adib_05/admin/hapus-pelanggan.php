
<?php
include("../config/koneksi.php");
$hasil = $_REQUEST['ID_Pelanggan'];
$perintah = mysqli_query($config, "delete from pelanggan where ID_Pelanggan='$hasil'");
if ($perintah) {
	echo "<script>alert('Data Pelanggan Berhasil Di Hapus!');
	location.href=('tampil-pelanggan.php');
	</script>;
";
} else{
	echo mysqli_error($config);
	//echo "<script>alert('Data pelanggan Gagal Di Hapus!'); history.back(self)</script>;";
}
?>