<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Aplikasi Kasir</title>

	<script language="javascript1.2"> 
	     function printpage() {
	          window.print();
	    }
	</script>
</head>

<body onload="printpage()">

	<h2>
		<center>Data Pelanggan</center>
	</h2>

	<table border="1" align="center">

		<tr>
			<th>NO</th>
			<th>ID_Pelanggan</th>
			<th>Nama_Pelanggan</th>
			<th>Alamat</th>
			<th>Nomor_Telepon</th>
		</tr>
		<?php
		include("../config/koneksi.php");
		$i = 1;
		$query = mysqli_query($config, "select * from pelanggan");
		while ($data = mysqli_fetch_array($query))  {
			echo "<tr>
			         <td>$i</td>
			         <td>$data[ID_Pelanggan]</td>
			         <td>$data[Nama_Pelanggan]</td>
			         <td>$data[Alamat]</td>
			         <td>$data[Nomor_Telepon]</td>
			     </tr>";
			$i = $i + 1;
		}
		?>
</body>

</html>