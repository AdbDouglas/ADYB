
<?php
include("../config/koneksi.php");
$hasil = $_REQUEST['ID_User'];
$perintah = mysqli_query($config, "delete from user where ID_User='$hasil'");
if ($perintah) {
	echo "<script>alert('Data User Berhasil Di Hapus!');
	location.href=('tampil-user.php');
	</script>;
";
} else{
	echo mysqli_error($config);
	//echo "<script>alert('Data User Gagal Di Hapus!'); history.back(self)</script>;";
}
?>