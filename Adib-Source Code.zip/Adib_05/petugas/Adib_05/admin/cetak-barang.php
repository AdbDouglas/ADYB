<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Aplikasi Kasir</title>

	<script language="javascript1.2"> 
	     function printpage() {
	          window.print();
	    }
	</script>
</head>

<body onload="printpage()">

	<h2>
		<center>Data Barang</center>
	</h2>

	<table border="1" align="center">

		<tr>
			<th>NO</th>
			<th>ID_Barang</th>
			<th>Nama_Barang</th>
			<th>Harga_Barang</th>
			<th>Stok_Barang</th>
		</tr>
		<?php
		include("../config/koneksi.php");
		$i = 1;
		$query = mysqli_query($config, "select * from barang");
		while ($data = mysqli_fetch_array($query))  {
			echo "<tr>
			         <td>$i</td>
			         <td>$data[ID_Barang]</td>
			         <td>$data[Nama_Barang]</td>
			         <td>Rp. $data[Harga_Barang]</td>
			         <td>$data[Stok_Barang]</td>
			     </tr>";
			$i = $i + 1;
		}
		?>
</body>

</html>