<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Aplikasi Kasir</title>

	<script language="javascript1.2"> 
	     function printpage() {
	          window.print();
	    }
	</script>
</head>

<body onload="printpage()">

	<h2>
		<center>Data User</center>
	</h2>

	<table border="1" align="center">

		<tr>
			<th>NO</th>
			<th>ID_User</th>
			<th>Nama</th>
			<th>Username</th>
			<th>Password</th>
			<th>Role</th>
		</tr>
		<?php
		include("../config/koneksi.php");
		$i = 1;
		$query = mysqli_query($config, "select * from user");
		while ($data = mysqli_fetch_array($query))  {
			echo "<tr>
			         <td>$i</td>
			         <td>$data[ID_User]</td>
			         <td>$data[Nama]</td>
			         <td>$data[Username]</td>
			         <td>$data[Password]</td>
			         <td>$data[Role]</td>
			     </tr>";
			$i = $i + 1;
		}
		?>
</body>

</html>