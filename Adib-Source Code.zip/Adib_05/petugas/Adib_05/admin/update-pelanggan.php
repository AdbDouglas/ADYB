<?php
include("../config/koneksi.php");
$ID_Pelanggan = $_POST['ID_Pelanggan'];
$Nama_Pelanggan = $_POST['Nama_Pelanggan'];
$Alamat = $_POST['Alamat'];
$Nomer_Telepon = $_POST['Nomer_Telepon'];

$query = mysqli_query($config, "update pelanggan set ID_Pelanggan='$ID_Pelanggan', Nama_Pelanggan='$Nama_Pelanggan', Alamat='$Alamat', Nomer_Telepon='$Nomer_Telepon' where ID_Pelanggan='$ID_Pelanggan'");
	
if ($query) {
	echo "<script>alert('Data Pelanggan Berhasil Di Update !!!');location.href=('tampil-pelanggan.php');</script>";
}else {
	echo "<script type='text/javascript'>alert('Data Produk Gagal Di Update !!!'); history.back(self);</script>'";
}
?>