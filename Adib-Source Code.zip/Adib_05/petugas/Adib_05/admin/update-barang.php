<?php
include("../config/koneksi.php");
$ID_Barang = $_POST['ID_Barang'];
$Nama_Barang = $_POST['Nama_Barang'];
$Harga_Barang = $_POST['Harga_Barang'];
$Stok_Barang = $_POST['Stok_Barang'];

$query = mysqli_query($config, "update barang set ID_Barang='$ID_Barang', Nama_Barang='$Nama_Barang', Harga_Barang='$Harga_Barang', Stok_Barang='$Stok_Barang' where ID_Barang='$ID_Barang'");
	
if ($query) {
	echo "<script>alert('Data Barang Berhasil Di Update !!!');location.href=('tampil-barang.php');</script>";
}else {
	echo "<script type='text/javascript'>alert('Data Produk Gagal Di Update !!!'); history.back(self);</script>'";
}
?>