<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" >
    <title>APP KASIR | PETUGAS</title>
  </head>
  <body>
    
    <nav class="navbar navbar-expand-lg navbar-light bg-success">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">App Kasir</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" 
                data-bs-target="#navbarNav" aria-controls="navbarNav" 
                aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="index.php">Home</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" 
                 role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Penjualan
              </a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="tambah-penjualan.php">Tambah Data</a></li>
                <li><a class="dropdown-item" href="tampil-penjualan.php">Tampil Data</a></li>
                <li><a class="dropdown-item" href="cetak-penjualan.php" target="_blank">Cetak Data</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" 
                 role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Barang
              </a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="tambah-barang.php">Tambah Barang</a></li>
                <li><a class="dropdown-item" href="Tampil-Barang.php">Tampil Barang</a></li>
                <li><a class="dropdown-item" href="cetak_barang.php" target="_blank">Cetak Barang</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" 
                 role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Pelanggan
              </a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="tambah-Pelanggan.php">Tambah Pelanggan</a></li>
                <li><a class="dropdown-item" href="tampil_pelanggan.php">Tampil Pelanggan</a></li>
                <li><a class="dropdown-item" href="cetak_pelanggan.php" target="_blank">Cetak Pelanggan</a></li>
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="../config/logout.php" 
                 onclick="return confirm('Apakah Anda Yakin Ingin Logout ???')">Logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container-fluid">
      <h3>Tambah Pelanggan</h3>
    </div>

    <div class="row">
      <form class="row g-3" action="simpan_pelanggan.php" method="post">
        <div class="col-12">
          <label for="id_pelanggan" class="form-label">ID Pelanggan</label>
          <input type="number" class="form-control" 
                 name="id_pelanggan" id="id_pelanggan" 
                 placeholder="ID Pelanggan" required 
                 onblur="checkIdPelanggan()">
        </div>

        <div class="col-12">
          <label for="nama" class="form-label">Nama Pelanggan</label>
          <input type="text" class="form-control" name="nama" id="nama" 
                 placeholder="Nama Pelanggan" required>
        </div>

        <div class="col-12">
          <label for="alamat" class="form-label">Alamat</label>
          <textarea class="form-control" name="alamat" id="alamat" 
                    placeholder="Alamat" required></textarea>
        </div>

        <div class="col-12">
          <label for="nomor_hp" class="form-label">Nomor Telepon</label>
          <input type="text" class="form-control" name="nomor_hp" 
                 id="nomor_hp" placeholder="Nomor Telepon" required>
        </div>

        <div class="col-12">
          <!-- Tambahkan ID pada tombol Simpan agar mudah diakses JavaScript -->
          <button type="submit" class="btn btn-primary" id="btnSimpan">Simpan</button>
        </div>
      </form>
    </div>

    <script src="../assets/js/bootstrap.bundle.min.js"></script>

    <script>
      // Fungsi AJAX untuk cek apakah ID sudah ada di DB
      function checkIdPelanggan() {
        let id_pelanggan = document.getElementById('id_pelanggan').value;
        
        // Jika user belum mengetik apa-apa, tidak perlu cek
        if (id_pelanggan === '') {
          return;
        }

        // Buat objek XMLHttpRequest
        let xhr = new XMLHttpRequest();
        // Metode POST ke file check_id_pelanggan.php
        xhr.open('POST', 'check_id_pelanggan.php', true);
        // Set header agar data terkirim sebagai form
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

        xhr.onload = function() {
          if (this.status === 200) {
            // Respons dari server (exists / not_exists)
            if (this.responseText.trim() === 'exists') {
              alert('ID Pelanggan sudah ada. Gunakan ID lain!');
              // Nonaktifkan tombol Simpan
              document.getElementById('btnSimpan').disabled = true;
            } else {
              // Aktifkan tombol Simpan jika ID tidak ada
              document.getElementById('btnSimpan').disabled = false;
            }
          }
        };
        // Kirim data ke check_id_pelanggan.php
        xhr.send('id_pelanggan=' + encodeURIComponent(id_pelanggan));
      }
    </script>
  </body>
</html>
