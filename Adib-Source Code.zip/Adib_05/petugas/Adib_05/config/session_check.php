<?php
session_start();

// Jika user belum login, arahkan ke login.php
if (!isset($_SESSION['role'])) {
    header("Location: ../login.php");
    exit();
}

// Pastikan role sesuai halaman yang diakses
function check_role($expected_role) {
    if ($_SESSION['role'] !== $expected_role) {
        header("Location: ../login.php");
        exit();
    }
}
?>
