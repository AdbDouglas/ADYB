<?php
session_start();
include("koneksi.php");

// Periksa apakah input tersedia
if (!isset($_POST['Username']) || !isset($_POST['Password'])) {
    echo "<script>alert('Mohon isi Username dan Password!'); window.history.back();</script>";
    exit();
}

// Hindari SQL Injection
$Username = mysqli_real_escape_string($config, $_POST['Username']);
$Password = mysqli_real_escape_string($config, $_POST['Password']);

// Jalankan query
$query = "SELECT * FROM user WHERE Username = '$Username' AND Password = '$Password'";
$login = mysqli_query($config, $query);

// Periksa apakah query berhasil dijalankan
if (!$login) {
    die("Query gagal: " . mysqli_error($config));
}

$cek = mysqli_num_rows($login);

if ($cek > 0) {
    $data = mysqli_fetch_assoc($login);

    // Periksa apakah kolom 'Role' ada di dalam hasil query
    if (isset($data['Role'])) {
        $_SESSION['Username'] = $Username;
        $_SESSION['Role'] = $data['Role']; // Simpan Role ke sesi

        // Arahkan berdasarkan peran
        if ($data['Role'] == "Admin") {
            header('Location: ../Admin/index.php');
        } elseif ($data['Role'] == "Petugas") {
            header('Location: ../petugas/index.php');
        } else {
            echo "<script>alert('Role tidak dikenali!'); window.history.back();</script>";
        }
        exit();
    } else {
        echo "<script>alert('Kolom Role tidak ditemukan dalam database!'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('Username atau Password Anda Salah!'); window.history.back();</script>";
}
?>
