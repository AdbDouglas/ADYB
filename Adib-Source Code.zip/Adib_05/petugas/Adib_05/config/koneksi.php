	<?php
	$server ="localhost";
	$user ="root";
	$pass ="";
	$database ="appkasir_adibs";

	$config = mysqli_connect($server, $user, $pass, $database) or die("gagal koneksi ke database");
	?>