<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    
    <title>Cetak Data Penjualan</title>
    
    <script>
        function printpage() {
            window.print();
        }
    </script>
</head>
<body onload="printpage()">
    <div class="container mt-4">
        <h2 class="text-center">Laporan Data Penjualan</h2>
        <hr>
        <table class="table table-bordered">
            <thead class="table-success">
                <tr>
                    <th>No</th>
                    <th>ID Penjualan</th>
                    <th>Tanggal Penjualan</th>
                    <th>Nama Pelanggan</th>
                    <th>Total Harga</th>
                    <th>Nama Barang</th>
                    <th>Jumlah</th>
                    <th>Harga Satuan</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include("../config/koneksi.php");
                $i = 1;
                $query = "
                    SELECT 
                        p.id_penjualan,
                        p.tgl_penjualan,
                        pl.nama AS nama_pelanggan,
                        p.total,
                        b.nama_barang,
                        dp.jumlah,
                        dp.harga,
                        dp.subtotal
                    FROM 
                        penjualan p
                    INNER JOIN 
                        detail_penjualan dp ON p.id_penjualan = dp.id_penjualan
                    INNER JOIN 
                        pelanggan pl ON p.id_pelanggan = pl.id_pelanggan
                    INNER JOIN 
                        barang b ON dp.id_barang = b.id_barang
                    ORDER BY 
                        p.id_penjualan, dp.id_barang";
                
                $result = mysqli_query($config, $query);
                
                while ($data = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                        <td>{$i}</td>
                        <td>{$data['id_penjualan']}</td>
                        <td>{$data['tgl_penjualan']}</td>
                        <td>{$data['nama_pelanggan']}</td>
                        <td>Rp. ".number_format($data['total'], 0, ',', '.')."</td>
                        <td>{$data['nama_barang']}</td>
                        <td>{$data['jumlah']} Pcs</td>
                        <td>Rp. ".number_format($data['harga'], 0, ',', '.')."</td>
                        <td>Rp. ".number_format($data['subtotal'], 0, ',', '.')."</td>
                    </tr>";
                    $i++;
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
