<?php
session_start();
if (!isset ($_SESSION['username'])){
  header(header:"location:../index.php");
  exit();
}
?><!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" >
    <title>APP KASIR | PETUGAS</title>
  </head>
  <body>
    
    <nav class="navbar navbar-expand-lg navbar-light bg-success">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">App Kasir</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" 
                data-bs-target="#navbarNav" aria-controls="navbarNav" 
                aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="index.php">Home</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" 
                 role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Penjualan
              </a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="tambah-penjualan.php">Tambah Data</a></li>
                <li><a class="dropdown-item" href="tampil-penjualan.php">Tampil Data</a></li>
                <li><a class="dropdown-item" href="cetak-penjualan.php" target="_blank">Cetak Data</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" 
                 role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Barang
              </a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="tambah-barang.php">Tambah Barang</a></li>
                <li><a class="dropdown-item" href="Tampil-Barang.php">Tampil Barang</a></li>
                <li><a class="dropdown-item" href="cetak_barang.php" target="_blank">Cetak Barang</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" 
                 role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Pelanggan
              </a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="tambah-Pelanggan.php">Tambah Pelanggan</a></li>
                <li><a class="dropdown-item" href="tampil_pelanggan.php">Tampil Pelanggan</a></li>
                <li><a class="dropdown-item" href="cetak_pelanggan.php" target="_blank">Cetak Pelanggan</a></li>
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="../config/logout.php" 
                 onclick="return confirm('Apakah Anda Yakin Ingin Logout ???')">
                Logout
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container-fluid">
      <h3>Home</h3>
      <h4>Selamat Datang Petugas</h4>
    </div>

    <div class="row">
      <div class="col">
        <div class="card" style="width: 18rem;">
          <div class="card-body bg-danger">
            <h5 class="card-title text-white">JUMLAH PENJUALAN</h5>
            <div class="display-4 text-white">
              <?php
              include("../config/koneksi.php");
              $sql = mysqli_query($config, "SELECT * FROM penjualan");
              $jml_data = mysqli_num_rows($sql);
              if ($jml_data > 0) {
                echo "<b>$jml_data</b>";
              }
              ?>
            </div>
            <a href="tampil-penjualan.php" class="text-white">
              <p class="card-text">Lihat Detail</p>
            </a>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card" style="width: 18rem;">
          <div class="card-body bg-warning">
            <h5 class="card-title text-white">JUMLAH BARANG</h5>
            <div class="display-4 text-white">
              <?php
              include("../config/koneksi.php");
              $sql = mysqli_query($config, "SELECT * FROM barang");
              $jml_data = mysqli_num_rows($sql);
              if ($jml_data > 0) {
                echo "<b>$jml_data</b>";
              }
              ?>
            </div>
            <a href="Tampil-Barang.php" class="card-text text-white">
              <p class="card-text">Lihat Detail</p>
            </a>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card" style="width: 18rem;">
          <div class="card-body bg-success">
            <h5 class="card-title text-white">JUMLAH PELANGGAN</h5>
            <div class="display-4 text-white">
              <?php
              include("../config/koneksi.php");
              $sql = mysqli_query($config, "SELECT * FROM pelanggan");
              $jml_data = mysqli_num_rows($sql);
              if ($jml_data > 0) {
                echo "<b>$jml_data</b>";
              }
              ?>
            </div>
            <a href="tampil_pelanggan.php" class="card-text text-white">
              <p class="card-text">Lihat Detail</p>
            </a>
          </div>
        </div>
      </div>
    </div>

    <script src="../assets/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
