<?php
include("../config/koneksi.php");
$ID_Pelanggan = $_POST['id_pelanggan'];
$Nama_Pelanggan = $_POST['nama'];
$Alamat = $_POST['alamat'];
$Nomor_Telepon = $_POST['nomor_hp'];

$query = mysqli_query($config, "insert into pelanggan (id_pelanggan, nama, alamat, nomor_hp) values ('$ID_Pelanggan','$Nama_Pelanggan','$Alamat','$Nomor_Telepon')");
if ($query) {
	echo "<script>alert('Data Pelanggan Tersimpan !!!');location.href=('tampil_pelanggan.php');</script>";
} else {
	echo "<script type='text/javascript'>alert('Data Pelanggan Gagal Tersimpan !!!'); history.back(self);</script'";
}
?>